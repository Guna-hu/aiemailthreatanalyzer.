const form = document.getElementById("analyzeForm");
const button = document.getElementById("analyzeButton");
const statusText = document.getElementById("formStatus");
const resultsPanel = document.getElementById("results");
const riskBadge = document.getElementById("riskBadge");
const riskScore = document.getElementById("riskScore");
const scoreCircle = document.getElementById("scoreCircle");

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}
async function fetchJSON(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function renderList(id, items, prop) {
  const list = document.getElementById(id);
  list.replaceChildren();
  if (!items || !items.length) { list.append(el("li", "", "No indicators found.")); return; }
  for (const item of items) list.append(el("li", "", typeof item === "string" ? item : (item[prop] || "No details available.")));
}
function renderResult(data) {
  resultsPanel.classList.remove("hidden");
  riskScore.textContent = String(data.score);
  riskBadge.textContent = `${data.level} risk`;
  riskBadge.className = `risk-badge risk-${data.level.toLowerCase()}`;
  scoreCircle.style.borderColor = data.level === "High" ? "var(--red)" : data.level === "Medium" ? "var(--yellow)" : "var(--green)";
  document.getElementById("resultTitle").textContent = data.level === "High" ? "High-risk indicators detected" : data.level === "Medium" ? "Review this message carefully" : "Few indicators detected";
  document.getElementById("resultDescription").textContent = `Risk score: ${data.score}/100. This is a heuristic score, not a probability.`;
  document.getElementById("modelStatus").textContent = data.model_available ? `ML prediction: ${data.model_label}. The model is trained on synthetic examples.` : "ML model unavailable. Rule-based analysis only.";
  renderList("findingsList", data.findings, "message");
  renderList("recommendationsList", data.recommendations, "");
  resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
}
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = {subject: document.getElementById("subject").value, sender: document.getElementById("sender").value, body: document.getElementById("body").value};
  if (!payload.body.trim()) { statusText.textContent = "Please enter an email body."; return; }
  button.disabled = true; statusText.textContent = "Analyzing email…";
  try {
    const data = await fetchJSON("/api/analyze", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)});
    renderResult(data); statusText.textContent = "Analysis complete."; await loadHistory();
  } catch (error) { statusText.textContent = error.message; }
  finally { button.disabled = false; }
});
async function loadHistory() {
  const container = document.getElementById("historyList");
  try {
    const data = await fetchJSON("/api/history");
    document.getElementById("totalScans").textContent = data.stats.total;
    document.getElementById("highScans").textContent = data.stats.high;
    document.getElementById("mediumScans").textContent = data.stats.medium;
    document.getElementById("lowScans").textContent = data.stats.low;
    container.replaceChildren();
    if (!data.history.length) { container.append(el("p", "muted", "No scans yet. Analyze a sample email to begin.")); return; }
    for (const item of data.history) {
      const row = el("article", "history-item"), details = el("div");
      details.append(el("strong", "", item.subject || "(No subject)"));
      details.append(el("small", "", `${item.sender || "Unknown sender"} · ${new Date(item.created_at).toLocaleString()}`));
      row.append(details, el("span", `history-score risk-${item.level.toLowerCase()}`, `${item.score}/100 · ${item.level}`));
      container.append(row);
    }
  } catch (error) { container.replaceChildren(el("p", "muted", `Unable to load history: ${error.message}`)); }
}
loadHistory();
