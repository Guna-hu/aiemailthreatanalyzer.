import csv
import io
import json
import os
from datetime import datetime, timezone
from flask import Flask, jsonify, render_template, request, Response
from analyzer import analyze_email, MODEL

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
DB_PATH = os.path.join(INSTANCE_DIR, "threats.db")
os.makedirs(INSTANCE_DIR, exist_ok=True)
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024


def get_db():
    import sqlite3
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with get_db() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL, subject TEXT NOT NULL, sender TEXT NOT NULL,
            score INTEGER NOT NULL, level TEXT NOT NULL, model_label TEXT NOT NULL,
            findings_json TEXT NOT NULL)""")


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "model_available": MODEL is not None})


@app.post("/api/analyze")
def api_analyze():
    if not request.is_json:
        return jsonify({"error": "Send JSON data."}), 415
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Invalid JSON object."}), 400
    fields = [data.get(k, "") for k in ("subject", "sender", "body")]
    if not all(isinstance(v, str) for v in fields):
        return jsonify({"error": "All fields must be text."}), 400
    subject, sender, body = [v.strip() for v in fields]
    if not body:
        return jsonify({"error": "Email body is required."}), 400
    if len(subject) > 500 or len(sender) > 500 or len(body) > 20000:
        return jsonify({"error": "Input exceeds the allowed field length."}), 413
    result = analyze_email(subject, sender, body)
    timestamp = datetime.now(timezone.utc).isoformat()
    with get_db() as db:
        cur = db.execute("""INSERT INTO scans
            (created_at, subject, sender, score, level, model_label, findings_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (timestamp, subject, sender, result["score"], result["level"],
             result["model_label"], json.dumps(result["findings"])))
        result["id"] = cur.lastrowid
    result["created_at"] = timestamp
    return jsonify(result)


@app.get("/api/history")
def api_history():
    try:
        limit = max(1, min(int(request.args.get("limit", "20")), 100))
    except ValueError:
        limit = 20
    with get_db() as db:
        rows = db.execute("SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        stats = {name.lower(): db.execute("SELECT COUNT(*) AS n FROM scans WHERE level = ?", (name,)).fetchone()["n"]
                 for name in ("High", "Medium", "Low")}
        stats["total"] = db.execute("SELECT COUNT(*) AS n FROM scans").fetchone()["n"]
    history = [{"id": r["id"], "created_at": r["created_at"], "subject": r["subject"],
                "sender": r["sender"], "score": r["score"], "level": r["level"],
                "model_label": r["model_label"], "findings": json.loads(r["findings_json"])} for r in rows]
    return jsonify({"history": history, "stats": stats})


@app.get("/api/export")
def api_export():
    with get_db() as db:
        rows = db.execute("SELECT * FROM scans ORDER BY id DESC").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Timestamp", "Subject", "Sender", "Risk Score", "Risk Level", "Model Label", "Findings"])
    def safe_cell(value):
        value = str(value)
        return "'" + value if value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else value
    for r in rows:
        writer.writerow([r["id"], safe_cell(r["created_at"]), safe_cell(r["subject"]), safe_cell(r["sender"]),
                         r["score"], r["level"], r["model_label"], safe_cell(r["findings_json"])])
    return Response("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=email_threat_report.csv"})


@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": "Request too large."}), 413


@app.errorhandler(500)
def internal_error(_error):
    return jsonify({"error": "An internal server error occurred."}), 500


init_db()
if __name__ == "__main__":
    # Local development only. Do not enable debug mode on a public server.
    app.run(debug=False, host="127.0.0.1", port=5000)
