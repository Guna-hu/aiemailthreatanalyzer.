# AI Email Threat Analyzer

An advanced-style educational cybersecurity project using Python, Flask, scikit-learn, SQLite, HTML, CSS, and JavaScript.

## Features
- Email subject/sender/body analysis
- Rule-based indicators with explanations
- Optional TF-IDF + Logistic Regression classifier
- Heuristic risk score from 0–100
- SQLite scan metadata history (email body is not stored)
- CSV export with basic spreadsheet-formula-injection mitigation
- Responsive dashboard and JSON API

## Requirements
Python 3.10+ recommended. Install dependencies in a virtual environment.

### Windows PowerShell
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python train_model.py
python app.py
```

### macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train_model.py
python app.py
```

Open http://127.0.0.1:5000 in your browser. Keep the app local for the college demo.

## Test
```bash
python -m unittest test_app -v
```

## API endpoints
- `GET /api/health` — server and model status
- `POST /api/analyze` — JSON body: `{"subject":"...","sender":"...","body":"..."}`
- `GET /api/history` — scan history and statistics
- `GET /api/export` — download CSV report

## Architecture
Browser UI → Flask validation/API → rule engine + optional ML pipeline → heuristic score/explanations → SQLite metadata history → dashboard/report.

## Important limitations
The bundled training set is tiny and synthetic, for demonstration only. The model is not production-quality and may misclassify emails. The risk score is a heuristic, not a calibrated probability. The tool does not verify sender authenticity, domain reputation, attachments, or URL safety. Do not enter real secrets or confidential email content. Before any real deployment, add authentication, authorization, CSRF protections as appropriate, rate limiting, HTTPS, retention controls, security logging, and independent model evaluation. Do not run Flask debug mode on a public server.
