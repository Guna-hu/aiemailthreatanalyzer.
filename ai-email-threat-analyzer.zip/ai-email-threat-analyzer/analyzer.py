"""Rule-based and optional ML email threat analysis for an educational project."""
import os
import re
import joblib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "models", "email_model.joblib")

RULES = [
    ("credential_request", re.compile(r"\b(password|passcode|login credentials|verification code|one[- ]time password|otp)\b", re.I), 22,
     "Mentions passwords, login credentials, or verification codes."),
    ("urgent_language", re.compile(r"\b(urgent|immediately|act now|within 24 hours|account suspended|account will be closed)\b", re.I), 15,
     "Uses urgency or account-suspension language."),
    ("financial_request", re.compile(r"\b(gift card|wire transfer|bank details|payment required|send money|claim your prize)\b", re.I), 20,
     "Contains a potentially suspicious financial request."),
    ("link_in_message", re.compile(r"https?://[^\s<>\"']+", re.I), 8,
     "Contains a web link; links alone do not prove danger."),
    ("attachment_pressure", re.compile(r"\b(open the attachment|enable macros|run this file|open attached file)\b", re.I), 18,
     "Encourages opening a file or enabling macros."),
    ("impersonation_language", re.compile(r"\b(IT support|help desk|security team|CEO|payroll department)\b", re.I), 5,
     "Claims to represent an organization or authority; verify independently."),
]

MODEL = None
try:
    if os.path.isfile(MODEL_PATH):
        MODEL = joblib.load(MODEL_PATH)
except Exception:
    MODEL = None


def analyze_email(subject: str, sender: str, body: str) -> dict:
    combined = f"Subject: {subject}\nFrom: {sender}\n\n{body}".strip()
    findings = []
    rule_score = 0
    matched = set()
    for rule_id, pattern, points, explanation in RULES:
        if pattern.search(combined):
            matched.add(rule_id)
            rule_score += points
            findings.append({"id": rule_id, "points": points, "message": explanation})

    if sender and re.search(r"\b(no-?reply|admin|support)\b", sender, re.I):
        findings.append({"id": "generic_sender", "points": 0,
                         "message": "The sender uses a generic account name. This is not proof of fraud."})

    model_label = "unavailable"
    model_probability = None
    model_score = 0
    if MODEL is not None:
        try:
            probabilities = MODEL.predict_proba([combined])[0]
            classes = list(MODEL.classes_)
            if "phishing" in classes:
                model_probability = float(probabilities[classes.index("phishing")])
                model_label = "phishing" if model_probability >= 0.5 else "likely_legitimate"
                model_score = round(model_probability * 100)
        except Exception:
            model_label = "unavailable"
            model_probability = None

    # Educational heuristic only; not a calibrated probability.
    score = min(100, round(rule_score * 0.70 + model_score * 0.30)) if MODEL is not None else min(100, rule_score)
    level = "High" if score >= 60 else "Medium" if score >= 30 else "Low"

    if MODEL is None:
        findings.append({"id": "model_unavailable", "points": 0,
                         "message": "ML model unavailable; this result uses rules only. Run train_model.py."})

    recommendations = []
    if matched:
        recommendations.append("Do not follow requests for passwords, verification codes, or unexpected payments.")
    if "link_in_message" in matched:
        recommendations.append("Verify destinations through an independently obtained official website; do not open suspicious links.")
    if "attachment_pressure" in matched:
        recommendations.append("Do not open unexpected attachments or enable macros.")
    recommendations.append("Verify unexpected requests using a trusted contact method.")
    return {"score": score, "level": level, "model_label": model_label,
            "model_probability": model_probability, "findings": findings,
            "recommendations": list(dict.fromkeys(recommendations)),
            "model_available": MODEL is not None}
