"""Train a tiny synthetic demonstration model. Not suitable for production."""
import os
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODEL_DIR, "email_model.joblib")

DATA = [
    ("Urgent verify your password immediately or your account will be suspended", "phishing"),
    ("You won a prize send your bank details to claim your reward", "phishing"),
    ("Open the attachment and enable macros to receive your payment", "phishing"),
    ("Your account is locked enter your one-time password now", "phishing"),
    ("CEO requests an urgent wire transfer to this new bank account", "phishing"),
    ("Click this link immediately to avoid account closure", "phishing"),
    ("IT support needs your login credentials to prevent suspension", "phishing"),
    ("Claim your gift card by sending money for a processing fee", "phishing"),
    ("Payroll verification required send your password today", "phishing"),
    ("Your package is delayed pay a fee using this unexpected link", "phishing"),
    ("Your mailbox will be deleted verify your account now", "phishing"),
    ("Please run the attached file to restore your access", "phishing"),
    ("The meeting agenda is attached for tomorrow's review", "legitimate"),
    ("Thank you for attending today's project meeting", "legitimate"),
    ("Your monthly report is ready in the company portal", "legitimate"),
    ("The library will be closed on the public holiday", "legitimate"),
    ("Please review the assignment before Friday's class", "legitimate"),
    ("The team meeting has moved to 3 PM tomorrow", "legitimate"),
    ("Your requested invoice is attached to this email", "legitimate"),
    ("Here are the notes from the training session", "legitimate"),
    ("Your appointment is confirmed for Monday morning", "legitimate"),
    ("The software update is available through our official portal", "legitimate"),
    ("Please find the class timetable for next semester", "legitimate"),
    ("We received your support request and will reply soon", "legitimate"),
]

model = Pipeline([
    ("tfidf", TfidfVectorizer(lowercase=True, ngram_range=(1, 2), sublinear_tf=True)),
    ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
])
model.fit([x[0] for x in DATA], [x[1] for x in DATA])
os.makedirs(MODEL_DIR, exist_ok=True)
joblib.dump(model, MODEL_PATH)
print(f"Model saved: {MODEL_PATH}")
print(f"Trained on {len(DATA)} synthetic examples. Educational use only; not production-ready.")
