import unittest
import app as project

class EmailThreatAnalyzerTests(unittest.TestCase):
    def setUp(self):
        project.app.config["TESTING"] = True
        self.client = project.app.test_client()

    def test_home_page(self):
        self.assertEqual(self.client.get("/").status_code, 200)

    def test_health(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["status"], "ok")

    def test_missing_body(self):
        response = self.client.post("/api/analyze", json={"subject":"Hello", "body":" "})
        self.assertEqual(response.status_code, 400)

    def test_wrong_content_type(self):
        response = self.client.post("/api/analyze", data="not json", content_type="text/plain")
        self.assertEqual(response.status_code, 415)

    def test_valid_email(self):
        response = self.client.post("/api/analyze", json={"subject":"Meeting", "sender":"colleague@example.test", "body":"Please review the meeting notes before Friday."})
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn(data["level"], ["Low", "Medium", "High"])
        self.assertGreaterEqual(data["score"], 0)
        self.assertLessEqual(data["score"], 100)

    def test_history(self):
        response = self.client.get("/api/history")
        self.assertEqual(response.status_code, 200)
        self.assertIn("history", response.json)
        self.assertIn("stats", response.json)

    def test_csv_export(self):
        response = self.client.get("/api/export")
        self.assertEqual(response.status_code, 200)
        self.assertIn("text/csv", response.content_type)

if __name__ == "__main__":
    unittest.main()
